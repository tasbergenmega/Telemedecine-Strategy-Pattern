package com.telemed.strategy;

import com.telemed.strategy.pricing.NightPricing;
import com.telemed.strategy.pricing.PricingStrategy;
import com.telemed.strategy.pricing.StandardPricing;
import com.telemed.strategy.pricing.VipPricing;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertTrue;

class PricingStrategyTest {

    @ParameterizedTest
    @MethodSource("provideAllStrategies")
    void priceIsNeverNegative(PricingStrategy strategy) {
        int result = strategy.calculate(1000);
        assertTrue(result >= 0, "The price cannot be negative");
    }

    static Stream<PricingStrategy> provideAllStrategies() {
        return Stream.of(
                new StandardPricing(),
                new VipPricing(),
                new NightPricing()
        );
    }
}