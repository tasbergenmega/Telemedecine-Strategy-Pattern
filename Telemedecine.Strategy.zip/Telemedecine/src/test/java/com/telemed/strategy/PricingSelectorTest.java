package com.telemed.strategy;

import com.telemed.strategy.external.FakeDemandProvider;
import com.telemed.strategy.pricing.NightPricing;
import com.telemed.strategy.pricing.StandardPricing;
import com.telemed.strategy.pricing.VipPricing;
import com.telemed.strategy.selector.PricingSelector;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PricingSelectorTest {

    @Test
    void selectorPicksVipWhenDemandIsHigh() {
        PricingSelector selector = new PricingSelector(new FakeDemandProvider(3));
        assertInstanceOf(VipPricing.class, selector.selectStrategy());
    }

    @Test
    void selectorPicksStandardWhenDemandIsLow() {
        PricingSelector selector = new PricingSelector(new FakeDemandProvider(1));
        assertInstanceOf(StandardPricing.class, selector.selectStrategy());
    }
}