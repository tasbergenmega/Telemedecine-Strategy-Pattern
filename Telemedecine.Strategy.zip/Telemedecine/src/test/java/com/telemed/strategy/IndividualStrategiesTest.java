package com.telemed.strategy;

import com.telemed.strategy.matching.CheapestDoctorStrategy;
import com.telemed.strategy.matching.HighestRatedDoctorStrategy;
import com.telemed.strategy.pricing.NightPricing;
import com.telemed.strategy.pricing.StandardPricing;
import com.telemed.strategy.pricing.VipPricing;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class IndividualStrategiesTest {

    @Test
    void standardPricingReturnsBasePrice() {
        assertEquals(1000, new StandardPricing().calculate(1000));
    }

    @Test
    void vipPricingAddsSurcharge() {
        assertEquals(6000, new VipPricing().calculate(1000));
    }

    @Test
    void nightPricingAppliesMultiplier() {
        assertEquals(1500, new NightPricing().calculate(1000));
    }

    @Test
    void highestRatedFindsTopDoctor() {
        String[] docs = {"Dr. A", "Dr. TOP", "Dr. B"};
        assertEquals("Dr. TOP", new HighestRatedDoctorStrategy().selectDoctor(docs));
    }

    @Test
    void cheapestFindsInternDoctor() {
        String[] docs = {"Dr. A", "Dr. Intern", "Dr. B"};
        assertEquals("Dr. Intern", new CheapestDoctorStrategy().selectDoctor(docs));
    }
}