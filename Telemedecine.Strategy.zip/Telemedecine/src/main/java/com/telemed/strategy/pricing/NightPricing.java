package com.telemed.strategy.pricing;

public class NightPricing implements PricingStrategy {
    @Override
    public int calculate(int basePrice) {
        return (int)(basePrice * 1.5);
    }
}