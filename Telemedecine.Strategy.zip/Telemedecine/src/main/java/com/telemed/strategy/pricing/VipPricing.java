package com.telemed.strategy.pricing;

public class VipPricing implements PricingStrategy {
    @Override
    public int calculate(int basePrice) {
        return basePrice + 5000;
    }
}