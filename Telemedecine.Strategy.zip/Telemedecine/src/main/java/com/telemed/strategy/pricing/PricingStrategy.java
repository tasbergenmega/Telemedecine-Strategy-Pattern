package com.telemed.strategy.pricing;

public interface PricingStrategy {
    int calculate(int basePrice);
}