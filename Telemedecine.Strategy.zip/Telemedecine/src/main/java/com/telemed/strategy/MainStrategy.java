package com.telemed.strategy;

import com.telemed.strategy.context.MatchingContext;
import com.telemed.strategy.context.PricingContext;
import com.telemed.strategy.external.FakeDemandProvider;
import com.telemed.strategy.matching.CheapestDoctorStrategy;
import com.telemed.strategy.matching.HighestRatedDoctorStrategy;
import com.telemed.strategy.matching.NearestDoctorStrategy;
import com.telemed.strategy.pricing.NightPricing;
import com.telemed.strategy.pricing.StandardPricing;
import com.telemed.strategy.pricing.VipPricing;
import com.telemed.strategy.selector.PricingSelector;

import java.util.Scanner;

public class MainStrategy {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        PricingContext pricingContext = new PricingContext(new StandardPricing());
        MatchingContext matchingContext = new MatchingContext(new NearestDoctorStrategy());

        String[] doctors = {"Dr. Smith", "Dr. TOP-House", "Dr. Intern-John"};
        int basePrice = 10000;

        while (true) {
            System.out.println("\n=== Strategy Demo ===");
            System.out.println("1) Show calculation using all pricing strategies (Family 1)");
            System.out.println("2) Choose pricing strategy manually");
            System.out.println("3) Automatic choice by Selector");
            System.out.println("4) Switch strategy at runtime");
            System.out.println("5) Show doctor matching (Family 2)");
            System.out.println("0) Exit");
            System.out.print("> ");

            String choice = sc.nextLine();

            switch (choice) {
                case "1" -> {
                    System.out.println("--- Same input (" + basePrice + "), different algorithms ---");
                    System.out.println("Standard: " + new StandardPricing().calculate(basePrice));
                    System.out.println("VIP:      " + new VipPricing().calculate(basePrice));
                    System.out.println("Night:    " + new NightPricing().calculate(basePrice));
                }
                case "2" -> {
                    System.out.print("Enter plan (STANDARD/VIP/NIGHT): ");
                    String type = sc.nextLine().toUpperCase();
                    if (type.equals("VIP")) pricingContext.setStrategy(new VipPricing());
                    else if (type.equals("NIGHT")) pricingContext.setStrategy(new NightPricing());
                    else pricingContext.setStrategy(new StandardPricing());
                    System.out.println("Total price: " + pricingContext.calculatePrice(basePrice));
                }
                case "3" -> {
                    PricingSelector selector = new PricingSelector(new FakeDemandProvider(3));
                    pricingContext.setStrategy(selector.selectStrategy());
                    System.out.println("Selector analyzed demand and chose a strategy.");
                    System.out.println("Total price: " + pricingContext.calculatePrice(basePrice));
                }
                case "4" -> {
                    System.out.println("Current price: " + pricingContext.calculatePrice(basePrice));
                    System.out.println("... Switching strategy at runtime to Night pricing ...");
                    pricingContext.setStrategy(new NightPricing());
                    System.out.println("New price: " + pricingContext.calculatePrice(basePrice));
                }
                case "5" -> {
                    System.out.println("Available doctors: " + String.join(", ", doctors));
                    System.out.print("Choose method (NEAREST/TOP/CHEAP): ");
                    String method = sc.nextLine().toUpperCase();
                    if (method.equals("TOP")) matchingContext.setStrategy(new HighestRatedDoctorStrategy());
                    else if (method.equals("CHEAP")) matchingContext.setStrategy(new CheapestDoctorStrategy());
                    else matchingContext.setStrategy(new NearestDoctorStrategy());
                    System.out.println("System matched doctor: " + matchingContext.findDoctor(doctors));
                }
                case "0" -> {
                    System.out.println("Exiting...");
                    return;
                }
                default -> System.out.println("Unknown command.");
            }
        }
    }
}