package com.telemed.strategy.matching;

public class CheapestDoctorStrategy implements DoctorMatchingStrategy {
    @Override
    public String selectDoctor(String[] availableDoctors) {
        // Логика: ищем интерна (Intern) - они дешевле
        for (String doc : availableDoctors) {
            if (doc.contains("Intern")) return doc;
        }
        return availableDoctors.length > 0 ? availableDoctors[0] : "Нет врачей";
    }
}