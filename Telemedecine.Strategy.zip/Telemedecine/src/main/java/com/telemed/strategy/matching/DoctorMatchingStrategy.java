package com.telemed.strategy.matching;

public interface DoctorMatchingStrategy {
    String selectDoctor(String[] availableDoctors);
}
