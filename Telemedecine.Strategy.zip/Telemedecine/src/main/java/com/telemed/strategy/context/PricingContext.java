package com.telemed.strategy.context;

import com.telemed.strategy.pricing.PricingStrategy;

public class PricingContext {
    private PricingStrategy strategy;

    public PricingContext(PricingStrategy strategy) {
        this.strategy = strategy;
    }

    // Смена стратегии на лету (Runtime switch)
    public void setStrategy(PricingStrategy strategy) {
        this.strategy = strategy;
    }

    // Контекст просто делегирует работу стратегии (без if/switch!)
    public int calculatePrice(int basePrice) {
        if (strategy == null) throw new IllegalStateException("Стратегия не выбрана");
        return strategy.calculate(basePrice);
    }
}