package com.telemed.strategy.selector;

import com.telemed.strategy.external.DemandProvider;
import com.telemed.strategy.pricing.*;

import java.time.LocalTime;

public class PricingSelector {
    private final DemandProvider demandProvider;

    public PricingSelector(DemandProvider demandProvider) {
        this.demandProvider = demandProvider;
    }
    public PricingStrategy selectStrategy() {
        int hour = LocalTime.now().getHour();
        int demand = demandProvider.getCurrentDemand();

        if (hour >= 22 || hour < 6) {
            return new NightPricing();
        }
        if (demand >= 3) {
            return new VipPricing();
        }
        return new StandardPricing();
    }
}