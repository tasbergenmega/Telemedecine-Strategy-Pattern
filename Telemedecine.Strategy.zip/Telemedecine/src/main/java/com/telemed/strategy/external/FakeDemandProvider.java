package com.telemed.strategy.external;

public class FakeDemandProvider implements DemandProvider {
    private final int demand;
    public FakeDemandProvider(int demand) { this.demand = demand; }
    @Override
    public int getCurrentDemand() { return demand; }
}