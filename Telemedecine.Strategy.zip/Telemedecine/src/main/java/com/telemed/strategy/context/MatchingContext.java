package com.telemed.strategy.context;

import com.telemed.strategy.matching.DoctorMatchingStrategy;

public class MatchingContext {
    private DoctorMatchingStrategy strategy;

    public MatchingContext(DoctorMatchingStrategy strategy) {
        this.strategy = strategy;
    }

    public void setStrategy(DoctorMatchingStrategy strategy) {
        this.strategy = strategy;
    }

    public String findDoctor(String[] availableDoctors) {
        if (strategy == null) throw new IllegalStateException("Стратегия не выбрана");
        return strategy.selectDoctor(availableDoctors);
    }
}