package com.telemed.strategy.matching;

public class HighestRatedDoctorStrategy implements DoctorMatchingStrategy {
    @Override
    public String selectDoctor(String[] availableDoctors) {
        // Логика: ищем врача с припиской "TOP" в имени
        for (String doc : availableDoctors) {
            if (doc.contains("TOP")) return doc;
        }
        return availableDoctors.length > 0 ? availableDoctors[0] : "Нет врачей";
    }
}