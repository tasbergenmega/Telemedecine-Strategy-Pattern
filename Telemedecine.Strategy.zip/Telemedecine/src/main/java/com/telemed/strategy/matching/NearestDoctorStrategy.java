package com.telemed.strategy.matching;

public class NearestDoctorStrategy implements DoctorMatchingStrategy {
    @Override
    public String selectDoctor(String[] availableDoctors) {
        // Логика: просто берем первого в списке (самый свободный по времени)
        return availableDoctors.length > 0 ? availableDoctors[0] : "Нет врачей";
    }
}