package com.telemed.strategy.pricing;

public class StandardPricing implements PricingStrategy {
    @Override
    public int calculate(int basePrice) {
        return basePrice;
    }
}