package com.telemed.strategy.external;

public interface DemandProvider {
    int getCurrentDemand(); // 1 - низкий, 2 - средний, 3 - высокий
}